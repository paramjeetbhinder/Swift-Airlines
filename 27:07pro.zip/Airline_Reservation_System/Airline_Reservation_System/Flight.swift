//
//  Flight.swift
//  Airline_Reservation_System
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Flight{
    var flightID : String?
    var flightFrom : String?
    var flightTo : String?
    var Date : String?
    var pilotID : String?
    
    var FlightID : String?
    {
        get{return self.flightID}
        set{self.flightID = newValue}
    }
    
    var FlightFrom : String?
    {
        get{return self.flightFrom}
        set{self.flightFrom = newValue}
    }
    
    var FlightTo : String?
    {
        get{return self.flightTo}
        set{self.flightTo = newValue}
    }
    
    var date : String?
    {
        get{return self.Date}
        set{self.Date = newValue}
    }
    
    var PilotID : String?
    {
        get{return self.pilotID}
        set{self.pilotID = newValue}
    }
    
    
    
    
    init(){
        self.flightID = ""
        self.flightFrom = ""
        self.flightTo = ""
      //  let formatter = DateFormatter()
      //  formatter.dateFormat = "yyyy/MM/dd HH:mm"
      //  let someDateTime = formatter.date(from: "2018/07/08 00:00")
        self.Date = ""
        self.pilotID = ""
    }
    
    init(flightID: String, flightFrom : String,flightTo : String, Date : String, airlineID : Int, airplaneID : String, pilotID : String){
        
        self.flightID = flightID
        self.flightFrom = flightFrom
        self.flightTo = flightTo
        self.Date = Date
        self.pilotID = pilotID
    }
    
    func displayData() -> String{
        var returnData = ""
        
        if self.flightID != nil {
            returnData += "\n flightID : " + self.flightID!
        }
        if self.flightFrom != nil {
            returnData += "\n flightFrom : " + self.flightFrom!
        }
        if self.flightTo != nil{
            returnData += "\n flightTo : " + self.flightTo!
        }
        if self.Date != nil{
            //let formatter = DateFormatter()
            returnData += "\n Flight Schedule Date: " + self.Date!                 /*formatter.string(from: */
        }
      
        if self.pilotID != nil{
            returnData += "\n Customer pilotID : " + self.pilotID!
        }
        return returnData
    }
    
    func registerFlight(){
        print("Enter Flight ID : ")
        self.flightID = readLine()!
        print("Departure From : ")
        self.flightFrom = readLine()!
        print("Arriving to : ")
        self.flightTo = readLine()!
        print("Enter Flight Schedule : ")
       // let formatter = DateFormatter()
       // formatter.dateFormat = "yyyy/MM/dd HH:mm"
       // let someDateTime = formatter.date(from: readLine()!)
        self.Date = readLine()!                         // someDateTime!
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        
        let formateDate = dateFormatter.date(from:flightScheduleDate!)!
        dateFormatter.dateFormat = "MM-dd-yyyy"
        
        print ("Print :\(dateFormatter.string(from: formateDate))")
        flightScheduleDate = dateFormatter.string(from: formateDate)
        
        
        print("Enter Pilot ID : ")
        self.pilotID = readLine()!
        
    }
}
