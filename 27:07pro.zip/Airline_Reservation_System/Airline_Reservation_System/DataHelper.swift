//
//  DataHelper.swift
//  Airline_Reservation_System
//
//  Created by MacStudent on 2018-07-27.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class DataHelper : Flight{
    var AirlinesList = [Int : Airlines]()
    var FlightList = [String : String]()
    
    override init(){
        self.loadAirlinesData()
        self.loadFlightsData()
}

func loadAirlinesData(){
    AirlinesList = [:]

    do{
        
        let Airlines1 = try Airlines(airlineID: 101, description: "International", airlinesType: "Air Bus")
        AirlinesList[(Airlines1.airlineID!)] =  Airlines1
        
        
        let Airlines2 = try Airlines(airlineID: 102, description: "All Nippon Airways", airlinesType: "Boeing787")
        AirlinesList[(Airlines2.airlineID!)] =  Airlines2
        
        let Airlines3 = try Airlines(airlineID: 103, description: "Emirates Airways", airlinesType: "Air Bus")
        AirlinesList[(Airlines3.airlineID!)] =  Airlines3
        
    }catch{
        print("Error: \(error)")
        
    }
    }
    func displayAirlines(){
        print("Airlines Details")
        
        print("\t AirlineID \t\t Airlines Description \t\t Airlines type")
        for (_, value) in self.AirlinesList.sorted(by: { $0.key < $1.key }){
            
            print("\t \(value.airlineID!)  \(value.description!)  \(value.airlinesType!)")
        }
    }

    func loadFlightsData(){
        FlightList = [:]
        
        do{
            
            let flight1 = try Flight(flightID: 10, flightFrom: "Toronto", flightTo: "Surrey", Date: "20-Sept-2018")
            FlightList[(flight1.flightID!)] = flight1
            
            let flight2 = try Flight(flightID: 20, flightFrom: "Delhi", flightTo: "Vancouver",Date: "20-Sept-2018" )
            FlightList[(flight2.flightID!)] = flight2
            
            let flight3 = try Flight(flightID: 30, flightFrom: "Mumbai", flightTo: "Sydney",Date: "20-Sept-2018" )
            FlightList[(flight3.flightID!)] = flight3
        }
    }
}
