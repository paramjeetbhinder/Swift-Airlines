//
//  Enquiry.swift
//  Airline_Reservation_System
//
//  Created by MacStudent on 2018-07-25.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Enquiry{
    var enquiryID : Int?
    var enquiryType : String?
    var enquiryTitle : String?
    var enquiryDescription : String?
    var enquiryDate : Date?
    
    var EnquiryID : Int?
    {
        get{return self.enquiryID}
        set{ self.enquiryID = newValue}
    }
    
    var EnquiryType : String?
    {
        get{return self.enquiryType}
        set{ self.enquiryType = newValue}
    }
    
    var EnquiryTitle : String?
    {
        get{return self.enquiryTitle}
        set{ self.enquiryTitle = newValue}
    }
    
    var EnquiryDescription : String?
    {
        get{return self.enquiryDescription}
        set{ self.enquiryDescription = newValue}
    }
    
    var EnquiryDate : Date?
    {
        get{return self.enquiryDate}
        set{ self.enquiryDate = newValue}
    }
    
    
    init(){
        self.enquiryID = 0
        self.enquiryType = ""
        self.enquiryTitle = ""
        self.enquiryDescription = ""
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy/MM/dd HH:mm"
        let someDateTime = formatter.date(from: "2018/07/08 00:00")
        
       
    }
    
    init(enquiryID : Int, enquiryType : String, enquiryTitle : String, enquiryDescription : String, enquiryDate : Date){
        
        self.enquiryID = enquiryID
        self.enquiryType = enquiryType
        self.enquiryTitle = enquiryTitle
        self.enquiryDescription = enquiryDescription
        self.enquiryDate = enquiryDate
        
    }
    
    func displayData() -> String{
        var returnData = ""
        
        if self.enquiryID != nil {
            returnData += "\n enquiryID : " + String(self.enquiryID! ?? 0)
        }
        if self.enquiryType != nil {
            returnData += "\n enquiryType : " + self.enquiryType!
        }
        if self.enquiryTitle != nil{
            returnData += "\n enquiryTitle : " + self.enquiryTitle!
        }
        if self.enquiryDescription != nil{
            returnData += "\n enquiryDescription : " + self.enquiryDescription!
        }
        if self.enquiryDate != nil{
            let formatter = DateFormatter()
            returnData += "\n Enquiry Date: " + formatter.string(from: self.enquiryDate!)
        }
        return returnData
    }
    
    func registerEnquiry(){
        print("Enter Enquiry ID : ")
        self.enquiryID = (Int)(readLine()!)
        print("Enter Enquiry Type : ")
        self.enquiryType = readLine()!
        print("Enter Enquiry Title : ")
        self.enquiryTitle = readLine()!
        print("Enter Enquiry Description : ")
        self.enquiryDescription = readLine()!
        print("Enter Enquiry Date : ")
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy/MM/dd HH:mm"
        let someDateTime = formatter.date(from: readLine()!)
        self.enquiryDate = someDateTime!
        
    }
}
