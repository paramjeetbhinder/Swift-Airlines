//
//  Flight.swift
//  Airline_Reservation_System
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Flight{
    var flightID : String?
    var flightFrom : String?
    var flightTo : String?
    var Date : String?
    var airlineID : String?
    var airplaneID : String?
    var pilotID : String?
    
    
    init(){
        self.flightID = ""
        self.flightFrom = ""
        self.flightTo = ""
        self.Date = ""
        self.airlineID = ""
        self.airplaneID = ""
        self.pilotID = ""
    }
    
    init(flightID: String, flightFrom : String,flightTo : String, Date : String, airlineID : String, airplaneID : String, pilotID : String){
        
        self.flightID = flightID
        self.flightFrom = flightFrom
        self.flightTo = flightTo
        self.Date = Date
        self.airlineID = airlineID
        self.airplaneID = airplaneID
        self.pilotID = pilotID
    }
    
    func displayData() -> String{
        var returnData = ""
        
        if self.flightID != nil {
            returnData += "\n flightID : " + self.flightID!
        }
        if self.flightFrom != nil {
            returnData += "\n flightFrom : " + self.flightFrom!
        }
        if self.flightTo != nil{
            returnData += "\n flightTo : " + self.flightTo!
        }
        if self.Date != nil{
            returnData += "\n Date : " + self.Date!
        }
        if self.airlineID != nil{
            returnData += "\n Customer airlineID : " + self.airlineID!
        }
        if self.airplaneID != nil{
            returnData += "\n Customer airplaneID : " + self.airplaneID!
        }
        if self.pilotID != nil{
            returnData += "\n Customer pilotID : " + self.pilotID!
        }
        return returnData
    }
    
    func registerUser(){
        print("Enter Flight ID : ")
        self.flightID = readLine()!
        print("Departure From : ")
        self.flightFrom = readLine()!
        print("Arriving to : ")
        self.flightTo = readLine()!
        print("Enter Flight Schedule : ")
        self.Date = readLine()!
        print("Enter Airline ID : ")
        self.airlineID = readLine()!
        print("Enter Airplane ID : ")
        self.airplaneID = readLine()!
        print("Enter Pilot ID : ")
        self.pilotID = readLine()!
        
    }
}
