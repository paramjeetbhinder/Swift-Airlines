import Foundation

class Passenger {
    
    var passengerID: Int?
    var passengerPassportNumber: String?
    var passengerName: String?
    var passengerMobile: String?
    var passengerEmail: String?
    var passengerAddress: String?
    var passengerBirthDate: String?
    
    
    
    
    init(){
        self.passengerID = 0
        self.passengerPassportNumber = ""
        self.passengerName = ""
        self.passengerMobile = ""
        self.passengerEmail = ""
        self.passengerAddress = ""
        self.passengerBirthDate = ""
        // super.init()
        
        
        
    }
    init( passengerID: Int, passengerPassportNumber: String , passengerName: String,  passengerMobile: String, passengerEmail: String, passengerAddress: String, passengerBirthDate: String) {
        
        
        self.passengerID = passengerID
        self.passengerPassportNumber = passengerName
        self.passengerName = passengerName
        self.passengerMobile = passengerMobile
        self.passengerEmail = passengerEmail
        self.passengerAddress = passengerAddress
        self.passengerBirthDate = passengerBirthDate
        
        
        //    super.init(flightID : flightID)
        
        
        
    }
    
    
    
    func displayData() -> String {
        var returnData = ""
        
        
        returnData += "\n Passenger ID: \(self.passengerID!)"
        returnData += "\n Passenger Passport Number: \(self.passengerPassportNumber ?? "")"
        returnData += "\n Passenger Name: \(self.passengerName ?? "")"
        returnData += "\n Passenger Mobile: \(self.passengerMobile ?? "")"
        returnData += "\n Passenger Email: \(self.passengerEmail ?? "")"
        returnData += "\n Passenger Address : \(self.passengerAddress ?? "")"
        returnData += "\n Passenger Date Of Birth: \(self.passengerBirthDate ?? "")"
        
        
        return returnData
    }
    
    func addPassenger(){
        
        
        print("Enter Passenger ID : ")
        self.passengerID = (Int)(readLine()!)!
        print("Enter Passenger Passport Number : ")
        self.passengerPassportNumber = readLine()
        print("Enter Passenger Name : ")
        self.passengerName = readLine()
        print("Enter Passenger Mobile : ")
        self.passengerMobile = readLine()
        print("Enter Passenger Email : ")
        self.passengerEmail = readLine()
        print("Enter Passenger Address : ")
        self.passengerAddress = readLine()
        print("Enter Passenger Date Of Birth (yyyy/mm/dd): ")
        self.passengerBirthDate = readLine()
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd" // This formate is input formated .
        
        let formateDate = dateFormatter.date(from:passengerBirthDate!)!
        dateFormatter.dateFormat = "MM-dd-yyyy1" // Output Formated
        
        print ("Print :\(dateFormatter.string(from: formateDate))")//Print :02-02-2018
        passengerBirthDate = dateFormatter.string(from: formateDate)
    }
}







