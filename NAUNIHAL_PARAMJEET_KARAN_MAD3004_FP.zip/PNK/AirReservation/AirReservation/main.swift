import Foundation

var choice = 1
let dataHelper = DataHelper()
var flight = Flight()


var choice1 : String
var seats : Int
var res =  Reservation()



var availableSeats : Int

var passenger1 = Passenger()
var passengerData : String
var pid : Int


availableSeats = 0
passengerData = ""
seats = 0

var e = Employee(employeeID: 1, employeeName: "Pram", employeeEmail: "jgksdf", employeeMobile: "458734895", employeeAddress: "gnjkrwgh", employeeDesignation: "jhgja", employeeSinNum: "fjethjdgj")


print("Airline Reseration System")

func  start()
{
    print("How many seats you want to reserve :")
    seats = Int(readLine()!)!
    availableSeats = res.getAvailSeats()
    if(seats > availableSeats)
    {
        print("Only \(availableSeats) available. Sorry for the inconvenience.")
    }
    else
    {
        passenger1.addPassenger()
        passengerData = passenger1.displayData()
        print(passengerData)
        
       
    }
}

if choice != 5
{
    
    print("\t 1 : Flight Details ")
    print("\t 2 : Airline Details")
    print("\t 3 : Employee Details")
    print("\t 4 : Add Reservation")
    
    
    print("---------------------------------------")
    print("Press suitable number : ")
    choice = (Int)(readLine()!)!
    
    
    switch choice{
    case 1:
        dataHelper.displayFlight()
        dataHelper.loadFlightData()
        print("Select your flight")
        choice1 = readLine()!
        switch(choice1)
        {
        case "1" :
            flight = Flight(flightID: "1", flightFrom: "Vancouver", flightTo: "Toronto", flightScheduleDate: "15-Aug-2018", flightType: FlightCategory.Domestic)
            print("Flight from Vancouver to Toronto scheduled 15-Aug-2018 is selected.")
            
            start()
            
        case "2" :
            flight = Flight(flightID: "2", flightFrom: "India", flightTo: "Toronto", flightScheduleDate: "20-Sept-2018", flightType: FlightCategory.International)
            print("Flight from India to Toronto scheduled 20-dept-2018 is selected")
            print(flight)
            start()
            
        case "3" :
            flight = Flight(flightID: "3", flightFrom: "Calgary", flightTo: "Vancouver", flightScheduleDate: "12-Aug-2018", flightType: FlightCategory.Domestic)
            print("Flight from Calgary to Vancouver scheduled 12-Aug-2018 is selected")
            start()
            
        case "4" :
            flight = Flight(flightID: "4", flightFrom: "Vancouver", flightTo: "Mumbai", flightScheduleDate: "14-Oct-2018", flightType: FlightCategory.International)
            print("Flight from Vancouver to Mumbai scheduled 14-Oct-2018 is selected")
            start()
            
        default:
            print("Enter a valid information.")
        
        exit(0)
        }
        
    case 2:
        dataHelper.displayAirlines()
        exit(0)
        
    case 3:
        print("Enter Employee data: ")
        print(e.registerEmployee())
        print(e.displayData())
       exit(0)
    case 4:
        res.addReservation()
     
        print("\nReservation details : ")
        print(res.displayData())
        print()
        
        print("\nThank you! \(passenger1.passengerName!) for reservation" )
 
    default:
        print("Please enter valid menu option.")
    }

    }










