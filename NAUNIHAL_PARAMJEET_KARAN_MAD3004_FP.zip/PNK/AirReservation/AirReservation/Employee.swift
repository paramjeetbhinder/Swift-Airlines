//
//  Employee.swift
//  AirReservation
//
//  Created by MacStudent on 2018-07-30.
//  Copyright © 2018 ParamNihalKaran. All rights reserved.
//

import Foundation

class Employee{
    var employeeID : Int?
    var employeeName : String?
    var employeeEmail : String?
    var employeeMobile : String?
    var employeeAddress : String?
    var employeeDesignation : String?
    var employeeSinNum : String?
    
    var EmployeeID : Int?
    {
        get{return self.employeeID}
        set{self.employeeID = newValue}
    }
    
    var EmployeeName : String?
    {
        get{return self.employeeName}
        set{self.employeeName = newValue}
    }
    
    var EmployeeEmail : String?
    {
        get{return self.employeeEmail}
        set{self.employeeEmail = newValue}
    }
    
    var EmployeeMobile : String?
    {
        get{return self.employeeMobile}
        set{self.employeeMobile = newValue}
    }
    
    var EmployeeAddress : String?
    {
        get{return self.employeeAddress}
        set{self.employeeAddress = newValue}
    }
    
    var EmployeeDesignation : String?
    {
        get{return self.employeeDesignation}
        set{self.employeeDesignation = newValue}
    }
    
    var EmployeeSinNum : String?
    {
        get{return self.employeeSinNum}
        set{self.employeeSinNum = newValue}
    }
    
    init(){
        self.employeeID = 0
        self.employeeName = ""
        self.employeeEmail = ""
        self.employeeMobile = ""
        self.employeeAddress = ""
        self.employeeDesignation = ""
        self.employeeSinNum = ""
    }
    
    init(employeeID: Int, employeeName : String, employeeEmail : String, employeeMobile : String, employeeAddress : String, employeeDesignation : String, employeeSinNum  : String){
        
        self.employeeID = employeeID
        self.employeeName = employeeName
        self.employeeEmail = employeeEmail
        self.employeeMobile = employeeMobile
        self.employeeAddress = employeeAddress
        self.employeeDesignation = employeeDesignation
        self.employeeSinNum = employeeSinNum
    }
    
    func displayData() -> String{
        var returnData = ""
        
        if self.employeeID != nil {
            returnData += "\n employeeID : " + String(self.employeeID! ?? 0)
        }
        if self.employeeName != nil {
            returnData += "\n employeeName : " + self.employeeName!
        }
        if self.employeeEmail != nil{
            returnData += "\n employeeEmail : " + self.employeeEmail!
        }
        if self.employeeMobile != nil{
            returnData += "\n employeeMobile : " + self.employeeMobile!
        }
        if self.employeeAddress != nil{
            returnData += "\n employeeAddress : " + self.employeeAddress!
        }
        if self.employeeDesignation != nil{
            returnData += "\n employee Designation : " + self.employeeDesignation!
        }
        if self.employeeSinNum != nil{
            returnData += "\n employee Sin Number : " + self.employeeSinNum!
        }
        return returnData
    }
    
    func registerEmployee(){
        print("Enter Employee ID : ")
        self.employeeID = (Int)(readLine()!)
        print("Enter Employee Name : ")
        self.employeeName = readLine()!
        print("Enter Employee Email : ")
        self.employeeEmail = readLine()!
        print("Enter Employee Mobile : ")
        self.employeeMobile = readLine()!
        print("Enter Employee Address : ")
        self.employeeAddress = readLine()!
        print("Enter Employee Designation : ")
        self.employeeDesignation = readLine()!
        print("Enter Employee Sin Number : ")
        self.employeeSinNum = readLine()!
        
    }
}
