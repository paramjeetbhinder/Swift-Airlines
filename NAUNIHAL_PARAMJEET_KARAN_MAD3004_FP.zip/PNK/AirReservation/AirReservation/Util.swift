import Foundation

class Util{
    static func drawLine()
    {
        let line = String(repeating: "-", count: 100)
        print(line)
    }
}
