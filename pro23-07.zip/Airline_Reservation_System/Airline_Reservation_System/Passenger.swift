//
//  Passenger.swift
//  Airline_Reservation_System
//
//  Created by MacStudent on 2018-07-23.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Passenger{
    var passengerID : String?
    var passportnum : String?
    var passengerName : String?
    var passengerMobile : String?
    var passengerEmail : String?
    var passengerAddress : String?
    var passengerBirthdate : String?
    
    var PassengerID : String?
    {
        get{return self.passengerID}
        set{ self.passengerID = newValue}
    }
    
    
    init(){
        self.passengerID = ""
        self.passportnum = ""
        self.passengerName = ""
        self.passengerMobile = ""
        self.passengerEmail = ""
        self.passengerAddress = ""
        self.passengerBirthdate = ""
    }
    
    init(passengerID: String, passportnum : String, passengerName : String, passengerMobile : String, passengerEmail : String, passengerAddress : String, passengerBirthdate  : String){
        
        self.passengerID = passengerID
        self.passportnum = passportnum
        self.passengerName = passengerName
        self.passengerMobile = passengerMobile
        self.passengerEmail = passengerEmail
        self.passengerAddress = passengerAddress
        self.passengerBirthdate = passengerBirthdate
    }
    
    func displayData() -> String{
        var returnData = ""
        
        if self.passengerID != nil {
            returnData += "\n passenger ID : " + self.passengerID!
        }
        if self.passportnum != nil {
            returnData += "\n Passport number : " + self.passportnum!
        }
        if self.passengerName != nil{
            returnData += "\n passenger Name : " + self.passengerName!
        }
        if self.passengerMobile != nil{
            returnData += "\n passenger Mobile : " + self.passengerMobile!
        }
        if self.passengerMobile != nil{
            returnData += "\n passenger Email : " + self.passengerEmail!
        }
        if self.passengerAddress != nil{
            returnData += "\n passenger Address : " + self.passengerAddress!
        }
        if self.passengerBirthdate != nil{
            returnData += "\n passenger Birthdate : " + self.passengerBirthdate!
        }
        return returnData
    }
    
    func registerPassenger(){
        print("Enter Passenger ID : ")
        self.passengerID = readLine()!
        print("Enter Passport Num : ")
        self.passportnum = readLine()!
        print("Enter Passenger Name : ")
        self.passengerName = readLine()!
        print("Enter Passenger Mobile : ")
        self.passengerMobile = readLine()!
        print("Enter Passenger Email : ")
        self.passengerEmail = readLine()!
        print("Enter Passenger Address : ")
        self.passengerAddress = readLine()!
        print("Enter Passenger Birthdate : ")
        self.passengerBirthdate = readLine()!
        
    }
}
