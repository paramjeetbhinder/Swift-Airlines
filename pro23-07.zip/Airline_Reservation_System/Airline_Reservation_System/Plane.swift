//
//  Plane.swift
//  Airline_Reservation_System
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Plane{
    var PlaneID : String?
    var TotalSeats : String?
    var TypeSeat : String?
    

    init(){
        self.PlaneID = ""
        self.TotalSeats = ""
        self.TypeSeat = ""
        
    }
    
    init(PlaneID: String, TotalSeats : String,TypeSeat : String){
        
        self.PlaneID = PlaneID
        self.TotalSeats = TotalSeats
        self.TypeSeat = TypeSeat
        
    }
    
    func displayData() -> String{
        var returnData = ""
        
        if self.PlaneID != nil {
            returnData += "\n PlaneID : " + self.PlaneID!
        }
        if self.TotalSeats != nil {
            returnData += "\n TotalSeats : " + self.TotalSeats!
        }
        if self.TypeSeat != nil{
            returnData += "\n TypeSeat : " + self.TypeSeat!
        }
     
        return returnData
    }
    
    func registerPlane(){
        print("Enter Plane ID : ")
        self.PlaneID = readLine()!
        print("Enter Total Seats Name : ")
        self.TotalSeats = readLine()!
        print("Enter Seat Type Email : ")
        self.TypeSeat = readLine()!
       
        
    }
}
