//
//  main.swift
//  Airline_Reservation_System
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation



var pp = Airlines()
pp.registerAirlines()

print(pp.displayData())

