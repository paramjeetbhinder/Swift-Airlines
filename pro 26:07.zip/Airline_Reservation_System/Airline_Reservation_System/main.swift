//
//  main.swift
//  Airline_Reservation_System
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation



//var keilla = Airlines()
//pp.registerAirlines()

//keilla.airlinesID = "abc"
//keilla.airlinesType = "xyz"
//keilla.description = "desc"

//keilla.registerAirlines()
//print(keilla.displayData())
let dateCurrent = Date()
print("Current Date: \(dateCurrent)")
let dateString = "07/21/2018"
let dateFormatter = DateFormatter()
dateFormatter.dateFormat = "MM/DD/YYYY"
let dateFromString = dateFormatter.date(from: dateString)
print ("date: \(dateFromString)")
let formatter = DateFormatter()
formatter.dateFormat = "yyyy/MM/dd HH:mm"
let someDateTime = formatter.date(from: "2018/07/08 00:00")


var k = Reservation()
k.registerReservation()
print(k.displayData())

