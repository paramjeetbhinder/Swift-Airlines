//
//  Passenger.swift
//  Airline_Reservation_System
//
//  Created by MacStudent on 2018-07-23.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Passenger{
    var passengerID : Int?
    var passportnum : String?
    var passengerName : String?
    var passengerMobile : String?
    var passengerEmail : String?
    var passengerAddress : String?
    var passengerBirthdate : Date?
    
    var PassengerID : Int?
    {
        get{return self.passengerID}
        set{ self.passengerID = newValue}
    }
    
    var Passportnum : String?
    {
        get{return self.passportnum}
        set{ self.passportnum = newValue}
    }
    
    var PassengerName : String?
    {
        get{return self.passengerName}
        set{ self.passengerName = newValue}
    }
    
    var PassengerMobile : String?
    {
        get{return self.passengerMobile}
        set{ self.passengerMobile = newValue}
    }
    
    var PassengerEmail : String?
    {
        get{return self.passengerEmail}
        set{ self.passengerEmail = newValue}
    }
    
    var PassengerAddress : String?
    {
        get{return self.passengerAddress}
        set{ self.passengerAddress = newValue}
    }
    
    var PassengerBirthdate : Date?
    {
        get{return self.passengerBirthdate}
        set{ self.passengerBirthdate = newValue}
    }
    
    
    init(){
        self.passengerID = 0
        self.passportnum = ""
        self.passengerName = ""
        self.passengerMobile = ""
        self.passengerEmail = ""
        self.passengerAddress = ""
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy/MM/dd HH:mm"
        let someDateTime = formatter.date(from: "2018/07/08 00:00")
    }
    
    init(passengerID: Int, passportnum : String, passengerName : String, passengerMobile : String, passengerEmail : String, passengerAddress : String, passengerBirthdate  : Date){
        
        self.passengerID = passengerID
        self.passportnum = passportnum
        self.passengerName = passengerName
        self.passengerMobile = passengerMobile
        self.passengerEmail = passengerEmail
        self.passengerAddress = passengerAddress
        self.passengerBirthdate = passengerBirthdate
    }
    
    func displayData() -> String{
        var returnData = ""
        
        if self.passengerID != nil {
            returnData += "\n passenger ID : " + String(self.passengerID! ?? 0)
        }
        if self.passportnum != nil {
            returnData += "\n Passport number : " + self.passportnum!
        }
        if self.passengerName != nil{
            returnData += "\n passenger Name : " + self.passengerName!
        }
        if self.passengerMobile != nil{
            returnData += "\n passenger Mobile : " + self.passengerMobile!
        }
        if self.passengerMobile != nil{
            returnData += "\n passenger Email : " + self.passengerEmail!
        }
        if self.passengerAddress != nil{
            returnData += "\n passenger Address : " + self.passengerAddress!
        }
        if self.passengerBirthdate != nil{
            let formatter = DateFormatter()
            returnData += "\n Passenger date of birth: " + formatter.string(from: self.passengerBirthdate!)
        }
        return returnData
    }
    
    func registerPassenger(){
        print("Enter Passenger ID : ")
        self.passengerID = (Int)(readLine()!)
        print("Enter Passport Num : ")
        self.passportnum = readLine()!
        print("Enter Passenger Name : ")
        self.passengerName = readLine()!
        print("Enter Passenger Mobile : ")
        self.passengerMobile = readLine()!
        print("Enter Passenger Email : ")
        self.passengerEmail = readLine()!
        print("Enter Passenger Address : ")
        self.passengerAddress = readLine()!
        print("Enter Passenger Birthdate : ")
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy/MM/dd HH:mm"
        let someDateTime = formatter.date(from: readLine()!)
    }
}
