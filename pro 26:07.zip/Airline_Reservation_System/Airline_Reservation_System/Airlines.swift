//
//  Airlines.swift
//  Airline_Reservation_System
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//


import Foundation

class Airlines{
    var airlineID : Int?
    var description : String?
    var airlinesType : String?
    
    var AirLineID : Int?
    {
        get{return self.airlineID}
        set{self.airlineID = newValue}
    }
    var Description : String?
    {
        get{return self.description}
        set{self.description = newValue}
    }
    var Airlinestype: String?
    {
        get{return self.airlinesType}
        set{self.airlinesType = newValue}
    }
    
    
    init(){
        self.airlineID = 0
        self.description = ""
        self.airlinesType = ""
        
    }
    
    init(airlineID: Int, description : String, airlinesType : String){
        
        self.airlineID = airlineID
        self.description = description
        self.airlinesType = airlinesType
       
    }
    
    func displayData() -> String{
        var returnData = ""
        
        if self.airlineID != nil {
            returnData += "\n airlinesID : " + String(self.airlineID ?? 0)
        }
        if self.description != nil {
            returnData += "\n description : " + self.description!
        }
        if self.airlinesType != nil{
            returnData += "\n airlinesType : " + self.airlinesType!
        }
        return returnData
    }
    
    func registerAirlines(){
        print("Enter Airlines ID : ")
        self.airlineID = (Int)(readLine()!)
        print("Enter Description : ")
        self.description = readLine()!
        print("Enter Airlines Type : ")
        self.airlinesType = readLine()!
        
    }
}
