//
//  Reservation.swift
//  Airline_Reservation_System
//
//  Created by MacStudent on 2018-07-25.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Reservation : Flight
{
    var reservationID : Int?
    var description : String?
    var passengerID : String?
    
    var reservationDate : Date?
    var seatNo : String?
    var status : String?
    var mealType : String?
    
    var ReservationID : Int?
    {
        get{return self.reservationID}
        set{ self.reservationID = newValue}
    }
    
    var Description : String?
    {
        get{return self.description}
        set{ self.description = newValue}
    }
    
    var PassengerID : String?
    {
        get{return self.passengerID}
        set{ self.passengerID = newValue}
    }
/*
    var FlightID : String?
    {
        get{return self.flightID}
        set{ self.flightID = newValue}
    }
*/
    var ReservationDate : Date?
    {
        get{return self.reservationDate}
        set{ self.reservationDate = newValue}
    }
    
    var SeatNo : String?
    {
        get{return self.seatNo}
        set{ self.seatNo = newValue}
    }
    
    var Status : String?
    {
        get{return self.status}
        set{ self.status = newValue}
    }
    
    var MealType : String?
    {
        get{return self.mealType}
        set{ self.mealType = newValue}
    }
    
    override init()
    {
        super.init()
        self.reservationID = 0
        self.description = ""
        self.passengerID = ""
        self.reservationDate = Date
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy/MM/dd HH:mm"
        let someDate = formatter.date(from: "2018/07/08 00:00")
        
        self.seatNo = ""
        self.status = ""
        self.mealType = ""
    }
/*
    override init(reservationID: Int, description : String, passengerID : String, reservationDate : Date, seatNo : String, status : String, mealType : String)
    {
        
        self.reservationID = reservationID
        self.description = description
        self.passengerID = passengerID
    //    self.flightID = flightID
        self.reservationDate = reservationDate
        self.seatNo = seatNo
        self.status = status
        self.mealType = mealType
    }
  */
    
        override func displayData() -> String
        {
        var returnData = ""
        super.displayData()
    
        if self.reservationID != nil {
            returnData += "\n reservationID : " + String(self.reservationID! ?? 0)
        }
        if self.description != nil {
            returnData += "\n description : " + self.description!
        }
        if self.passengerID != nil{
            returnData += "\n passengerID : " + self.passengerID!
        }
    /*
        if self.flightID != nil{
            returnData += "\n flightID : " + self.flightID!
        }
*/
        if self.reservationDate != nil{
            let formatter = DateFormatter()
            returnData += "\n Reservation Date : " + formatter.string(from: self.reservationDate!)
           
            
        }
        if self.seatNo != nil{
            returnData += "\n seatNo : " + self.seatNo!
        }
        if self.status != nil{
            returnData += "\n status : " + self.status!
        }
        if self.mealType != nil{
            returnData += "\n mealType : " + self.mealType!
        }
        return returnData
    }
    
    func registerReservation(){
        print("Enter Reservation ID : ")
        self.reservationID = (Int)(readLine()!)
        print("Enter Description : ")
        self.description = readLine()!
        print("Enter Passenger ID : ")
        self.passengerID = readLine()!
        print("Enter Flight ID : ")
        self.flightID = readLine()!
        print("Enter Reservation Date : ")
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy/MM/dd HH:mm"
        let someDateTime = formatter.date(from: readLine()!)
        self.reservationDate = someDateTime!
        print("Enter Seat Number : ")
        self.seatNo = readLine()!
        print("Enter Reservation Status : ")
        self.status = readLine()!
        print("Enter Meal Type : ")
        self.mealType = readLine()!
        
    }
}
