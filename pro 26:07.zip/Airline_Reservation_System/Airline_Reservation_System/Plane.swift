//
//  Plane.swift
//  Airline_Reservation_System
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Plane{
    var planeID : String?
    var totalSeats : Int?
    var typeSeat : [String]
    
    var PlaneID : String?
    {
        get{return self.planeID}
        set{self.planeID = newValue}
    }
    var TotalSeats : Int?
    {
        get{return self.totalSeats}
        set{self.totalSeats = newValue}
    }
    var TypeSeat: [String]
    {
        get{return self.typeSeat}
        set{self.typeSeat = newValue}
    }

    init(){
        self.planeID = ""
        self.totalSeats = 0
        self.typeSeat = []
        
    }
    
    init(planeID: String, totalSeats : Int,typeSeat : [String]){
        
        self.planeID = planeID
        self.totalSeats = totalSeats
        self.typeSeat = typeSeat
        
    }
    
    func displayData() -> String{
        var returnData = ""
        
        if self.planeID != nil {
            returnData += "\n Plane ID : " + self.planeID!
        }
        if self.totalSeats != nil {
            returnData += "\n total Seats : " + String(self.totalSeats! ?? 0)
        }
        if self.typeSeat != nil{
            for j in typeSeat
            {
                returnData += j
            }
        }
     
        return returnData
    }
    
    func registerPlane(){
        print("Enter Plane ID : ")
        self.planeID = readLine()!
        print("Enter Total Seats Name : ")
        self.totalSeats = (Int)(readLine()!)
        print("Enter Seat Type Email : ")
        for i in typeSeat
        {
            typeSeat.append((i))
        }
    }
    
    func editPlane()
    {
        
        
    }
}
