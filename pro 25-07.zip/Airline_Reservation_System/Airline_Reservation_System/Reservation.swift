//
//  Reservation.swift
//  Airline_Reservation_System
//
//  Created by MacStudent on 2018-07-25.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Reservation{
    var reservationID : String?
    var description : String?
    var passengerID : String?
    var flightID : String?
    var reservationDate : String?
    var seatNo : String?
    var status : String?
    var mealType : String?
  
    
    
    init(){
        self.reservationID = ""
        self.description = ""
        self.passengerID = ""
        self.flightID = ""
        self.reservationDate = ""
        self.seatNo = ""
        self.status = ""
        self.mealType = ""
    }
    
    init(reservationID: String, description : String, passengerID : String, flightID : String, reservationDate : String, seatNo : String, status : String, mealType : String){
        
        self.reservationID = reservationID
        self.description = description
        self.passengerID = passengerID
        self.flightID = flightID
        self.reservationDate = reservationDate
        self.seatNo = seatNo
        self.status = status
        self.mealType = mealType
    }
    
    func displayData() -> String{
        var returnData = ""
        
        if self.reservationID != nil {
            returnData += "\n reservationID : " + self.reservationID!
        }
        if self.description != nil {
            returnData += "\n description : " + self.description!
        }
        if self.passengerID != nil{
            returnData += "\n passengerID : " + self.passengerID!
        }
        if self.flightID != nil{
            returnData += "\n flightID : " + self.flightID!
        }
        if self.reservationDate != nil{
            returnData += "\n reservationDate : " + self.reservationDate!
        }
        if self.seatNo != nil{
            returnData += "\n seatNo : " + self.seatNo!
        }
        if self.status != nil{
            returnData += "\n status : " + self.status!
        }
        if self.mealType != nil{
            returnData += "\n mealType : " + self.mealType!
        }
        return returnData
    }
    
    func registerReservation(){
        print("Enter Reservation ID : ")
        self.reservationID = readLine()!
        print("Enter Description : ")
        self.description = readLine()!
        print("Enter Passenger ID : ")
        self.passengerID = readLine()!
        print("Enter Flight ID : ")
        self.flightID = readLine()!
        print("Enter Reservation Date : ")
        self.reservationDate = readLine()!
        print("Enter Seat Number : ")
        self.seatNo = readLine()!
        print("Enter Reservation Status : ")
        self.status = readLine()!
        print("Enter Meal Type : ")
        self.mealType = readLine()!
        
    }
}
