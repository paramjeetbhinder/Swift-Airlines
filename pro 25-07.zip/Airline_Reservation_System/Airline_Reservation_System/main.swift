//
//  main.swift
//  Airline_Reservation_System
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation



var keilla = Airlines()
//pp.registerAirlines()

//keilla.airlinesID = "abc"
//keilla.airlinesType = "xyz"
//keilla.description = "desc"

keilla.registerAirlines()
print(keilla.displayData())
