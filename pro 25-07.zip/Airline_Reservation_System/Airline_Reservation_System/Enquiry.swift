//
//  Enquiry.swift
//  Airline_Reservation_System
//
//  Created by MacStudent on 2018-07-25.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Enquiry{
    var enquiryID : String?
    var enquiryType : String?
    var enquiryTitle : String?
    var enquiryDescription : String?
    var enquiryDate : String?
    
    
    
    init(){
        self.enquiryID = ""
        self.enquiryType = ""
        self.enquiryTitle = ""
        self.enquiryDescription = ""
        self.enquiryDate = ""
       
    }
    
    init(enquiryID : String, enquiryType : String, enquiryTitle : String, enquiryDescription : String, enquiryDate : String){
        
        self.enquiryID = enquiryID
        self.enquiryType = enquiryType
        self.enquiryTitle = enquiryTitle
        self.enquiryDescription = enquiryDescription
        self.enquiryDate = enquiryDate
        
    }
    
    func displayData() -> String{
        var returnData = ""
        
        if self.enquiryID != nil {
            returnData += "\n enquiryID : " + self.enquiryID!
        }
        if self.enquiryType != nil {
            returnData += "\n enquiryType : " + self.enquiryType!
        }
        if self.enquiryTitle != nil{
            returnData += "\n enquiryTitle : " + self.enquiryTitle!
        }
        if self.enquiryDescription != nil{
            returnData += "\n enquiryDescription : " + self.enquiryDescription!
        }
        if self.enquiryDate != nil{
            returnData += "\n enquiryDate : " + self.enquiryDate!
        }
        return returnData
    }
    
    func registerEnquiry(){
        print("Enter Enquiry ID : ")
        self.enquiryID = readLine()!
        print("Enter Enquiry Type : ")
        self.enquiryType = readLine()!
        print("Enter Enquiry Title : ")
        self.enquiryTitle = readLine()!
        print("Enter Enquiry Description : ")
        self.enquiryDescription = readLine()!
        print("Enter Enquiry Date : ")
        self.enquiryDate = readLine()!
        
    }
}
