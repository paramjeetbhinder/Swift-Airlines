//
//  Airlines.swift
//  Airline_Reservation_System
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//


import Foundation

class Airlines{
    var airlinesID : String?
    var description : String?
    var airlinesType : String?
    
    var AirLinesID : String?
    {
        get{return self.airlinesID}
        set{self.airlinesID = newValue}
    }
    var Description : String?
    {
        get{return self.description}
        set{self.description = newValue}
    }
    var Airlinestype: String?
    {
        get{return self.airlinesType}
        set{self.airlinesType = newValue}
    }
    
    
    init(){
        self.airlinesID = ""
        self.description = ""
        self.airlinesType = ""
        
    }
    
    init(airlinesID: String, description : String, airlinesType : String){
        
        self.airlinesID = airlinesID
        self.description = description
        self.airlinesType = airlinesType
       
    }
    
    func displayData() -> String{
        var returnData = ""
        
        if self.airlinesID != nil {
            returnData += "\n airlinesID : " + self.airlinesID!
        }
        if self.description != nil {
            returnData += "\n description : " + self.description!
        }
        if self.airlinesType != nil{
            returnData += "\n airlinesType : " + self.airlinesType!
        }
        return returnData
    }
    
    func registerAirlines(){
        print("Enter Airlines ID : ")
        self.airlinesID = readLine()!
        print("Enter Description : ")
        self.description = readLine()!
        print("Enter Airlines Type : ")
        self.airlinesType = readLine()!
        
    }
}
